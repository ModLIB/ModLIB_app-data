package io.isaac300.modlib.app.data;
import java.io.*;
import java.net.*;

class URLManager {
	public static String getUrl(String link){

		BufferedReader bufread = null;
		HttpURLConnection urlcon;
		URL url;
		StringBuilder builder;
		String text = "";

		try{
			url = new URL(link);
			urlcon = (HttpURLConnection) url.openConnection();
			builder = new StringBuilder();
			bufread = new BufferedReader(new InputStreamReader(urlcon.getInputStream()));

			int i = 0;
			while((text = bufread.readLine()) != null){
				i++;
				builder.append(text);
			}
			return builder.toString();
		} catch (MalformedURLException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			if (bufread != null){
				try {
					bufread.close();
				} catch (IOException e) {
					e.printStackTrace();
					return null;
				}//catch
			}//if
		}//finally
	}//getUrl//urlmanager
}
