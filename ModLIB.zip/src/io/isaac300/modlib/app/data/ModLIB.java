package io.isaac300.modlib.app.data;
import android.widget.*;
import java.net.*;
import java.io.*;
import android.os.*;
import android.app.*;
import android.content.*;
import android.text.*;
import android.net.*;

public class ModLIB{
	public static Context ctx;
	public static String dump,version,preview,about;
	public static boolean isCheckDump,isCheckUpdate,isCheckAbout;
	public static Dialog dg1,dg2,dg3;
	public static EditText ed;
	public static TextView tv1,tv2;
	private byte[] BYTE;
	
	public String readFile(String path){
		try{
			FileInputStream fopen = new FileInputStream(path);
			BYTE = new byte[fopen.available()];
			fopen.read(BYTE);
			fopen.close();
		}catch(IOException srr){
			
		}
		return new String(BYTE);
	}
	
	void rewriteFile(String path,String content){
		try{
			File f = new File(path);
			f.createNewFile();
			OutputStreamWriter wr = new OutputStreamWriter(new FileOutputStream(f));
			wr.append(content);
			wr.close();
		}catch(IOException err){

		}
	}
	
public class MainTask extends AsyncTask<String, Void, String>{
		private ProgressDialog pd;

		private String tinydatabase;
	protected void onPreExecute(){
		super.onPreExecute();
		pd = new ProgressDialog(ctx);
		pd.setCancelable(false);
		if(isCheckDump==true){
			pd.setMessage("Loading dump function...");
		}
		if(isCheckUpdate==true){
			pd.setMessage("Verifying updates...");
		}
		if(isCheckAbout==true){
			pd.setMessage("Loading about ModLIB...");
		}
		pd.show();
	}

	@Override
	protected String doInBackground(String... url){
		if(isCheckDump==true){
			dump = URLManager.getUrl("https://raw.githubusercontent.com/ModLIB/ModLIB_app-data/master/dump.txt");
		}
		if(isCheckUpdate==true){
			 tinydatabase = URLManager.getUrl("https://raw.githubusercontent.com/ModLIB/ModLIB_app-data/master/tinydatabase.txt");
		}
		if(isCheckAbout==true){
			about = URLManager.getUrl("https://raw.githubusercontent.com/ModLIB/ModLIB_app-data/master/about.txt");
		}
	return "";
	}

	
	@Override
	protected void onPostExecute(String str) {
		if(isCheckDump==true){
			ed = new EditText(ctx);
			dg1 = new Dialog(ctx);
			ed.setText(Html.fromHtml(dump));
			dg1.setContentView(ed);
			dg1.setTitle(Html.fromHtml("<center>DUMP</center>"));
			dg1.show();
			isCheckDump = false;
		}
		if(isCheckUpdate==true){
			version = tinydatabase.substring(8,12);
			preview = tinydatabase.substring(21,22);
			tv1 = new TextView(ctx);
			dg2 = new Dialog(ctx);
			tv1.setText(Html.fromHtml("<center>"+"CURRENT VERSION:"+version+"<br>"+"CURRENT PREVIEW:"+preview+"</center>"));
			dg2.setContentView(tv1);
			if(version.equals(readFile("sdcard/version.ml"))&&preview.equals(readFile("sdcard/preview.ml"))){
				dg2.setTitle(Html.fromHtml("<center>CHECK VERSION</center>"));
			}else{
				tv1.setText(Html.fromHtml("MODLIB HAVE AN NEW VERSION PLS MAKE THE DOWNLOAD IN THE MAIN PAGE PRESSING BUTTON 'DOWNLOAD LATEST VERSION' :D"));
				rewriteFile("sdcard/version.ml",version);
				rewriteFile("sdcard/preview.ml",preview);
			}
			dg2.show();
			isCheckUpdate = false;
		}
		if(isCheckAbout==true){
			tv2 = new TextView(ctx);
			dg3 = new Dialog(ctx);
			tv2.setText(Html.fromHtml(about));
			dg3.setContentView(tv2);
			dg3.setTitle(Html.fromHtml("<center>ABOUT MODLIB</center>"));
			dg3.show();
			isCheckAbout = false;
		}
		pd.dismiss();
	}

}
}
