package io.isaac300.modlib.app;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import io.isaac300.modlib.app.data.*;
import android.content.*;
import android.widget.TableLayout.*;
import android.util.*;
import android.webkit.*;
import java.io.*;
import android.net.*;

public class MainActivity extends Activity implements OnClickListener{
    @Override
	private LinearLayout main,l1,l2,l3;
	private Button b2;
	private Button b1;
	private Button b3;

	private Button b4;
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        ModLIB.ctx = this;
		onLoad();
    }
	
	void onLoad(){
		File f = new File("sdcard/version.ml");
		if(f.exists()==false){
			try{
				f.createNewFile();
				OutputStreamWriter wr = new OutputStreamWriter(new FileOutputStream(f));
				wr.append("1000");
				wr.close();
			}catch (IOException e)
			{}
		}
		File ff = new File("sdcard/preview.ml");
		if(ff.exists()==false){
			try{
				ff.createNewFile();
				OutputStreamWriter wr = new OutputStreamWriter(new FileOutputStream(ff));
				wr.append("1");
				wr.close();
			}catch (IOException e)
			{}
		}
		main = new LinearLayout(this);
		main.setOrientation(1);
		LayoutManager();
		setContentView(main);
	}
	
	void LayoutManager(){
		//* MAIN *\\
		b1 = new Button(this);
		b2 = new Button(this);
		b3 = new Button(this);
		b1.setText("VIEW DUMP");
		b2.setText("CHECK VERSION");
		b3.setText("ABOUT MODLIB");
		b4 = new Button(this);
		b4.setText("UPDATE LATEST VERSION");
		b1.setOnClickListener(this);
		b2.setOnClickListener(this);
		b3.setOnClickListener(this);
		b4.setOnClickListener(this);
		main.addView(b1);
		main.addView(b2);
		main.addView(b3);
		main.addView(b4);
	}

	@Override
	public void onClick(View p1){
		if(p1==b1){
			ModLIB.isCheckDump = true;
			new ModLIB().new MainTask().execute();
		}
		if(p1==b2){
			ModLIB.isCheckUpdate = true;
			new ModLIB().new MainTask().execute();
		}
		if(p1==b3){
			ModLIB.isCheckAbout = true;
			new ModLIB().new MainTask().execute();
		}
		if(p1==b4){
			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/ModLIB/ModLIB_app-data/blob/master/ModLIB.apk?raw=true")));
		}
	}
	
	
}
