/** Automatically generated file. DO NOT MODIFY */
package io.isaac300.modlib.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}